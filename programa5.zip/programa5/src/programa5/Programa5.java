/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programa5;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author parker
 */
public class Programa5 {

    public static void main(String[] args) {
       List<String> nombres = new ArrayList<>();
       nombres.add("juan");
       nombres.add("pedro");
       nombres.add("jose");
       nombres.add("maria");
       nombres.add("sofia");
       //itero la lista y actualizo el primer indice 
       nombres.forEach((String s) -> {
           // if( s.equals("pedro")){
               // System.out.println("estoy en el primer indice");
               //modificamos el primer indice
               nombres.set(1, "Pedro");
          // }
          // System.out.println(s);
       });
       nombres.forEach((String t) ->{
           System.out.println(t);
       });
    }
    
}
