/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programa2;

import java.util.Scanner;

/**
 *
 * @author parker
 */
public class Programa2 {

    public static void main(String[] args) {
       int a,b,c;
       Scanner sc = new Scanner(System.in);
       System.out.println("dame el primer numero: ");
       a = sc.nextInt();
       System.out.println("dame el segundo numero: ");
       b = sc.nextInt();
       System.out.println("dame el tercer numero: ");
       c = sc.nextInt();
      if( a > b && a > c && b > c){
          System.out.println("numero " + a + " segundo " + b + " tercer " + c);
      }else if( b > a && b > c && a > c){
          System.out.println("numero " + b + " segundo " + a + " tercer " + c);
      }else if( c > a && c > b && b > a){
          System.out.println("numero " + c + " segundo " + b + " tercer " + a);
      }
       //System.out.println("numero " + a + " segundo " + b + " tercer " + c);
    }
    
}
