/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programa4;

import java.util.Scanner;

/**
 *
 * @author parker
 */
public class Programa4 {

    public static void main(String[] args) {
        int bandera = 0;
        int entrada;
       int numero;
       numero = (int)(Math.random()*100+1);
       // System.out.println(numero);
       Scanner sc = new Scanner(System.in);
       System.out.println("dame un numero: ");
       entrada = sc.nextInt();
       while( bandera != 4){
           if( numero == entrada){
               System.out.println("acertaste el numero");
               break;
           }
           if( numero > entrada){
               System.out.println("el numero aleatorio es mayor al que diste");
           }
           if( numero < entrada){
               System.out.println("el numero aleatorio es menor al que diste");
           }
           System.out.println("dame otro numero tienes 4 intentos apartir de ahora: ");
           entrada = sc.nextInt();
           bandera++;
       }
       System.out.println("gracias por participar");
    }
    
}
