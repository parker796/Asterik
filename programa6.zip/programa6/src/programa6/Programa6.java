/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programa6;

/**
 *
 * @author parker
 */
public class Programa6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[][] A = { {2, 0, 1}, 
                    {3, 0, 0},
                    {5, 1, 1}
                    };
        int[][] B = { {1, 0, 1},
                        {1, 2, 1},
                        {1, 1, 0}
            
                    };
        int[][] producto = new int[A.length][A.length];
         for (int a = 0; a < A.length; a++) {
             for (int i = 0; i < A.length; i++) {
                int suma = 0;
                for (int j = 0; j < A[0].length; j++) {
                     suma += A[i][j] * B[j][a];
                }
                producto[i][a] = suma;
         }
                    
                }
         
        for (int i = 0; i < A.length; i++) {
            for (int j = 0; j < A.length; j++) {
                System.out.printf("%d ", producto[i][j]);
            }
            System.out.print("\n");
        }
    }
    }
    

