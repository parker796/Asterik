/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programa3;

import java.util.Scanner;

/**
 *
 * @author parker
 */
public class Programa3 {

    public static void main(String[] args) {
        int n;
        Scanner sc = new Scanner(System.in);
        System.out.println("dame un numero: ");
        n = sc.nextInt();
        
        for( int i = 0; i < n; i++){
            for( int j = 0; j < n; j++){
                if( n == 1){
                    j++;
                }
            }
        }
    }
    
}
